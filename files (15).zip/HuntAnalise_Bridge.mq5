//+------------------------------------------------------------------+
//|                                          HuntAnalise_Bridge.mq5  |
//|              Lê dados do gráfico e abre o app Hunt Análise        |
//|  SETUP:                                                           |
//|  1. Salvar hunt_analise.html em C:\HuntAnalise\hunt_analise.html  |
//|  2. Compilar no MetaEditor (F7)                                   |
//|  3. Arrastar da aba Scripts para o gráfico                        |
//+------------------------------------------------------------------+
#property copyright "HuntAnalise Bridge v1.2"
#property version   "1.20"
#property script_show_inputs

#import "shell32.dll"
int ShellExecuteW(int hwnd, string lpOperation, string lpFile,
                  string lpParameters, string lpDirectory, int nShowCmd);
#import

#define ICHI_TENKANSEN   0
#define ICHI_KIJUNSEN    1
#define ICHI_SENKOUSPANA 2
#define ICHI_SENKOUSPANB 3

input string InpHTMLPath  = "C:\\HuntAnalise\\hunt_analise.html"; // Caminho do app
input double InpCapital   = 10000;
input double InpRiskPct   = 1.0;
input int    InpRSIPeriod = 14;
input string InpSupply    = "";
input string InpDemand    = "";


//+------------------------------------------------------------------+
//| Extrai parâmetros da URL e monta JSON                            |
//+------------------------------------------------------------------+
string JsonFromURL(string url)
  {
   // Remove a parte base da URL
   int q = StringFind(url, "?");
   if(q < 0) return "{}";
   string qs = StringSubstr(url, q + 1);

   string pairs[];
   int n = StringSplit(qs, '&', pairs);

   string json = "{";
   for(int i = 0; i < n; i++)
     {
      string kv[];
      if(StringSplit(pairs[i], '=', kv) < 2) continue;
      string key = kv[0];
      string val = kv[1];
      if(i > 0) json += ",";
      json += "\"" + key + "\":\"" + val + "\"";
     }
   json += "}";
   return json;
  }

void OnStart()
  {
   string sym    = Symbol();
   string tf_str = TFToString(Period());
   int    digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double price  = SymbolInfoDouble(sym, SYMBOL_BID);
   double rsi    = GetRSI(InpRSIPeriod);
   double tenkan = GetIchi(ICHI_TENKANSEN,  0);
   double kijun  = GetIchi(ICHI_KIJUNSEN,   0);
   double senA   = GetIchi(ICHI_SENKOUSPANA, 0);
   double senB   = GetIchi(ICHI_SENKOUSPANB, 0);
   double kumo_hi = MathMax(senA, senB);
   double kumo_lo = MathMin(senA, senB);

   string ctx = "";
   if(tenkan < kijun)       ctx = ctx + "Dead cross Tenkan/Kijun|";
   else                     ctx = ctx + "Golden cross Tenkan/Kijun|";
   if(price < kumo_lo)      ctx = ctx + "Viés bearish geral|";
   else if(price > kumo_hi) ctx = ctx + "Viés bullish geral|";
   else                     ctx = ctx + "Preço dentro da nuvem|";
   if(rsi >= 70)            ctx = ctx + "RSI sobrecomprado|";
   else if(rsi <= 30)       ctx = ctx + "RSI sobrevendido|";

   string fpath = InpHTMLPath;
   StringReplace(fpath, "\\", "/");
   string url = "file:///" + fpath + "?pair=" + sym + "&tf=" + tf_str;
   url = url + "&price="   + DoubleToString(price, digits);
   url = url + "&rsi="     + DoubleToString(rsi, 1);
   url = url + "&tenkan="  + DoubleToString(tenkan, digits);
   url = url + "&kijun="   + DoubleToString(kijun, digits);
   url = url + "&kumo_hi=" + DoubleToString(kumo_hi, digits);
   url = url + "&kumo_lo=" + DoubleToString(kumo_lo, digits);
   url = url + "&capital=" + DoubleToString(InpCapital, 2);
   url = url + "&risk="    + DoubleToString(InpRiskPct, 1);
   url = url + "&ctx="     + ctx;
   if(InpSupply != "") url = url + "&supply=" + InpSupply;
   if(InpDemand != "") url = url + "&demand=" + InpDemand;

   Print("Hunt Análise — ", sym, " ", tf_str,
         " | Preço: ", price, " | RSI: ", rsi,
         " | Tenkan: ", tenkan, " | Kijun: ", kijun);

   //--- Salva URL em arquivo temporário e abre via bat
   string tmp_path = "C:\\HuntAnalise\\last_url.txt";
   int fh = FileOpen("hunt_last_url.txt", FILE_WRITE|FILE_TXT|FILE_ANSI);
   if(fh != INVALID_HANDLE)
     {
      FileWriteString(fh, url);
      FileClose(fh);
     }
   int r = ShellExecuteW(0, "open", "C:\\HuntAnalise\\ABRIR_HUNT.bat", "", "C:\\HuntAnalise\\", 1);
   if(r > 32) Print("App aberto com sucesso!");
   else       Print("Erro ao abrir browser. Código: ", r);
  }

double GetRSI(int period)
  {
   double c[];
   ArraySetAsSeries(c, true);
   if(CopyClose(Symbol(), Period(), 0, period + 2, c) <= 0) return 50.0;
   double g = 0, l = 0;
   for(int i = 0; i < period; i++)
     { double d = c[i] - c[i+1]; if(d > 0) g += d; else l -= d; }
   double ag = g / period, al = l / period;
   if(al == 0) return 100.0;
   return NormalizeDouble(100.0 - 100.0 / (1.0 + ag / al), 1);
  }

double GetIchi(int idx, int shift)
  {
   int h = iIchimoku(Symbol(), Period(), 9, 26, 52);
   if(h == INVALID_HANDLE) return 0;
   int att = 0;
   while(BarsCalculated(h) <= 0 && att < 100) { Sleep(50); att++; }
   double buf[];
   ArraySetAsSeries(buf, true);
   int n = CopyBuffer(h, idx, shift, 1, buf);
   IndicatorRelease(h);
   return (n > 0) ? buf[0] : 0;
  }

string TFToString(ENUM_TIMEFRAMES tf)
  {
   switch(tf)
     {
      case PERIOD_M1:  return "M1";
      case PERIOD_M5:  return "M5";
      case PERIOD_M15: return "M15";
      case PERIOD_M30: return "M30";
      case PERIOD_H1:  return "H1";
      case PERIOD_H4:  return "H4";
      case PERIOD_D1:  return "D1";
      case PERIOD_W1:  return "W1";
      case PERIOD_MN1: return "MN";
      default:         return EnumToString(tf);
     }
  }
